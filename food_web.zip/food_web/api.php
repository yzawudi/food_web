<?php

$data = $_POST;
echo json_encode($data);